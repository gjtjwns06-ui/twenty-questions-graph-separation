# 완성 논문 LaTeX 패키지

main.tex를 XeLaTeX, TeX Live 2025 이상으로 컴파일하세요.
Overleaf에서 실제 확인한 환경은 XeLaTeX / TeX Live 2026입니다.
그림 3개, 표 15개와 참고문헌 20개가 소스 안에 있어 외부 그림이나 BibTeX가 필요 없습니다.
Twenty_Questions_Paper_Final.pdf는 온라인에서 내려받은 실제 18쪽 PDF입니다.

evidence.json은 원고에 사용한 원시 입력의 경로와 해시,
verification.json은 보존 검사와 온라인 대조,
visual_qa.json은 PDF 렌더 검수 기록입니다.
이 ZIP은 독립 컴파일용이며 원시 실험 전체와 학습 모델 파일은 포함하지 않습니다.
기존 연구 작업 폴더의 runs/, final_work/, novelty_work/에 자료가 보존되어 있습니다.

온라인 프로젝트의 main document는 Twenty_Questions_Final.tex입니다.
이 ZIP의 main.tex는 같은 완성 원고이고, 온라인에 보존한 원래 main.tex와 다릅니다.

핵심 결과는 균등 탐욕 동점에 대한 선형 regret 대비입니다.
ML 개선 미확정, 실패한 증폭, 미완결 계산을 원고에 유지했습니다.
최초성·외부 동료 심사·형식 증명 인증을 주장하지 않습니다.
